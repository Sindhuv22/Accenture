# Reflection Brief

**Name:** Sai Sindhu  
**Date of run:** 2026-09-23

Every conclusion below is tied to a result from my own captured run. Exact machine-generated values and assertion names are preserved so that a reviewer can locate them in the evidence pack.

## 0. Environment

- **Operating system:** Linux 6.6.97+ x86_64
- **Python version:** Python 3.13.0
- **Execution date:** 2026-09-23
- **Live execution:** No successful live run was completed. The System 1 live pipeline was attempted, but the configured service returned HTTP 400 with a service-budget-exceeded response. Offline and replay evidence was therefore used where allowed.

## 1. Validated and Routed Insurance-Policy Pipeline

### Verification result

The complete policy test suite reported `45 passed, 3 skipped`. No live `routing_decisions.json` was generated because the live request did not authenticate successfully within the available service budget. The approved offline routing and calibration evidence was used instead.

### 1.1 Retry boundary

The missing-source case set the required `endorsements` field to `None`, representing an absent Schedule A. The captured test asserted:

```text
isinstance(result, RetryFutileEscalation)
result.field == "endorsements"
result.detected_pattern == "endorsements_absent"
client.call_count == 1
```

This result shows that the pipeline made one client call and then escalated. A further retry could not recover information that was absent from the source, so stopping avoided unnecessary calls and prevented the system from fabricating an endorsement value.

### 1.2 Interpreting the router

A live routing record was unavailable because the pipeline request returned HTTP 400 with a service-budget-exceeded error. The offline tests in `tests/test_us04_routing.py` exercised human-review paths for low confidence, integration failure, and reviewer disagreement. I therefore relied on the test evidence without claiming a live routing record or live route counts that were not produced.

### 1.3 Why aggregate calibration can mislead

My calibration output included:

```text
umbrella  exclusions      n=2 conf=0.93 acc=0.00 brier=0.865
OVERALL brier=0.291
```

The `umbrella / exclusions` slice had zero observed accuracy even though its mean predicted confidence was `0.93`. The overall Brier score of `0.291` was much less alarming than the slice-level Brier score of `0.865`. The slice therefore exposed a concentrated weakness that the aggregate result concealed.

## 2. Schema-Enforced Two-Pass Mortgage Extraction

### Verification result

The mortgage test suite reported `25 passed`. The document `fixtures/documents/appraisal_informal_sqft.txt` was classified as `appraisal`.

### 2.1 Two different guarantees

Schema-conforming tool output guarantees that the response has the required structure and types. It does not prove that related numeric fields agree. In my discrepancy run, the calculated monthly total was `9642.17`, while the stated total was `10892.17`. The validator returned `consistent: false` with a delta of `-1250.0`.

This demonstrates why both protections are needed. Schema enforcement addresses structural reliability, while deterministic arithmetic validation checks a business relationship across otherwise valid fields.

### 2.2 Preserving missing information

The missing-bonus run returned:

```text
bonus_monthly: null
bonus_ytd: null
```

The source did not state those bonus values. Returning `null` preserved that absence and kept it distinguishable from a real zero or an estimated amount. This behavior is safer for underwriting because downstream users can see that the evidence was unavailable.

### 2.3 Normalization

The appraisal source described the property area as `about 2,400 sq ft`. The structured output normalized this to:

```text
gross_living_area_sqft: 2400
```

The normalized integer is easier for downstream validation and comparison to consume, while the extraction still remains grounded in the source wording.

## 3. Provenance-Preserving Multi-Source Synthesis

### Verification result

The supply-chain suite reported `34 passed`. The generated artifact was `briefing.md`, and the on-time-delivery disagreement appeared in the `Contested` section.

### 3.1 Preserve disagreement instead of hiding it

The briefing retained both measurements:

```text
95.0 percent - supplier_audit (as of 2026-04-10)
78.0 percent - logistics (as of 2026-04-05)
```

Keeping both values, source names, and dates makes the disagreement inspectable. Producing a single blended number would remove the provenance needed to understand why the sources differ and would create certainty not supported by the evidence.

### 3.2 Behavior when a source becomes unavailable

The timeout run included:

```text
### late_shipment_count [missing source: timeout reading logistics]
- missing source: timeout reading logistics
```

The investigation still completed, but information affected by the unavailable logistics source was explicitly marked incomplete. This is more reliable than silently dropping the source, treating the missing result as evidence, or terminating the entire investigation.

`production_capacity_utilization` was also incomplete, but for a different reason: no source reported that metric. The briefing therefore distinguished source failure from ordinary evidence absence.

### 3.3 Dates as a guardrail

The supplier-audit value was dated `2026-04-10`, while the logistics value was dated `2026-04-05`. Because the measurements came from different dates, the difference cannot automatically be interpreted as a contradiction at exactly the same point in time. Preserving the dates prevents the synthesis layer from overstating what the conflict proves.

## 4. Synthesis

### 4.1 Reliability principle

The principle I would carry into my own backend work is: **evaluate model output with independent, deterministic checks and preserve the evidence behind every important decision**.

The mortgage discrepancy run illustrates this most directly. The extraction process returned structured values, but the validator independently calculated `9642.17`, compared it with the stated `10892.17`, and produced `consistent: false` with a `-1250.0` delta. The system did not treat a valid-looking response as automatically correct.

### 4.2 Confidence is not correctness

The policy calibration result provides a second example. The `umbrella / exclusions` slice had confidence `0.93` but accuracy `0.00`. A high confidence value therefore did not establish correctness. Slice-level evaluation was necessary to reveal the weak subgroup.

### 4.3 Applying the principle

For a Java and Spring Boot workflow that extracts structured data from documents, I would combine DTO or schema validation with separate business-rule checks. Financial totals would be recalculated, missing source values would remain explicitly nullable, and uncertain or inconsistent records would be routed for review. I would also log the source, extracted fields, validation results, discrepancies, retry decisions, escalation reasons, and final route. These observability records would make failures traceable instead of allowing incorrect results to pass silently.

