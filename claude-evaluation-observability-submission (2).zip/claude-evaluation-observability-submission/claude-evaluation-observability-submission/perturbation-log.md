# Perturbation Log

This log records one controlled perturbation for each system. Each result is compared with the corresponding normal behavior and is grounded in the captured run evidence.

## System 1: Validated and Routed Insurance-Policy Pipeline

### Controlled change
I exercised the provided missing-source case in `tests/test_us01_retry.py`. In this case, the recorded extraction response sets the required `endorsements` field to `None`, representing an absent Schedule A rather than a formatting error that another model call could repair.

### Command

```bash
.venv/bin/pytest tests/test_us01_retry.py -v
```

### Expected behavior
Because the required value is absent from the source, the pipeline should classify the failure as futile to retry, stop after the initial call, and escalate the record rather than asking the model to invent the missing information.

### Observed behavior

```text
assert isinstance(result, RetryFutileEscalation)
assert result.field == "endorsements"
assert result.detected_pattern == "endorsements_absent"
assert client.call_count == 1
```

### Comparison with the unperturbed behavior
The normal routing suite contains successful records that can proceed to `auto_approve`. The missing-source case instead produces `RetryFutileEscalation` after exactly one client call. The safeguard distinguishes evidence that is genuinely unavailable from an output defect that might be corrected by retrying.

### Evidence reference
`01-policy-pipeline/perturbation.txt` or the captured output for `tests/test_us01_retry.py`.

## System 2: Resilient Mortgage-Document Extraction

### Controlled change
I modified the recorded replay response `fixtures/recorded_responses/1c76db72dd978c9c.json`, changing `stated_monthly_total` from `10892.17` to `12000.00`. This experiment changes only the stated total so that the independently calculated line-item sum can be compared against a larger mismatch.

### Command

```bash
.venv/bin/mortgage-extract fixtures/documents/income_sum_mismatch.txt --mode replay
```

### Expected behavior
The extractor should preserve the calculated amount of `9642.17`, read the perturbed stated amount as `12000.00`, and report a larger inconsistency instead of treating the structurally valid numbers as mutually consistent.

### Observed behavior

```text
"stated_monthly_total": 12000.0
"calculated": 9642.17
"delta": -2357.83
"consistent": false
```

### Comparison with the unperturbed behavior
The baseline run reported a stated total of `10892.17`, a calculated total of `9642.17`, and a delta of `-1250.0`. After the fixture change, the calculated amount remained `9642.17`, while the stated amount became `12000.0` and the delta became `-2357.83`. This replay-based experiment demonstrates that the mathematical validator responds to the changed recorded value. It was not a fresh live-model extraction.

### Evidence reference
`02-mortgage/sum-mismatch-run.txt` and the preserved baseline run output.

## System 3: Provenance-Preserving Supply-Chain Investigation

### Controlled change
I enabled the supplied `--simulate-timeout` option for the logistics source.

### Command

```bash
.venv/bin/supply-chain-investigate meridian --offline --simulate-timeout
```

### Expected behavior
The coordinator should complete the investigation without treating the unavailable logistics source as evidence. Metrics that depend on that source should be marked incomplete with an explicit timeout annotation.

### Observed behavior

```text
### late_shipment_count [missing source: timeout reading logistics]
- missing source: timeout reading logistics
```

### Comparison with the unperturbed behavior
In the normal offline run, `on_time_delivery_rate` appeared as contested because the supplier audit reported `95.0 percent` and logistics reported `78.0 percent`. In the timeout run, information dependent on logistics was marked incomplete instead of being silently omitted or causing the whole investigation to abort. `production_capacity_utilization` remained incomplete because no source supplied that metric.

### Evidence reference
`03-supply-chain/investigation-run.txt`, `03-supply-chain/timeout-run.txt`, and `03-supply-chain/briefing.md`.
